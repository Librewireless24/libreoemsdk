package com.cumulations.libreV2.adapter;

import android.view.View;

public interface OnClickInterfaceListener {
    public void onInterfaceClick(View view, int position);
}
