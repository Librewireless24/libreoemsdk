package com.cumulations.libreV2.roomdatabase

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [CastLiteUUIDDataClass::class], version = 2, exportSchema = false)
abstract class CastLiteDatabase : RoomDatabase() {
    abstract fun castLiteDao(): CastLiteDao

    companion object {

        @Volatile
        private var INSTANCE: CastLiteDatabase? = null

        fun getDatabase(context: Context): CastLiteDatabase {
            // if the INSTANCE is not null, then return it,
            // if it is, then create the database
            if (INSTANCE == null) {
                synchronized(this) {
                    // Pass the database to the INSTANCE
                    INSTANCE = buildDatabase(context)
                }
            }
            // Return database.
            return INSTANCE!!
        }

        private fun buildDatabase(context: Context): CastLiteDatabase {
            return Room.databaseBuilder(context.applicationContext,
                CastLiteDatabase::class.java, "cast_lite_database")
                .build()
        }
    }
}