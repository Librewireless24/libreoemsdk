package com.cumulations.libreV2.activity;

import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_APP2DEV_CONNECT_WIFI;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_APP2DEV_FRIENDLYNAME;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_APP2DEV_SCAN_WIFI;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_APP2DEV_SECURITY_CHECK;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_APP2DEV_STOP_M;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_CRED_FAILURE;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_CRED_RECEIVED;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_CRED_SUCCESS;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_SCAN_LIST_DATA;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_SCAN_LIST_END;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_SCAN_LIST_START;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_STARTED;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_WIFI_AP_NOT_FOUND;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_WIFI_CONNECTED;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_WIFI_CONNECTING;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_WIFI_CONNECTING_FAILED;
import static com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEUtils.BLE_SAC_DEV2APP_WIFI_DISCONNECTED;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.cumulations.libreV2.AppUtils;
import com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEPacket;
import com.cumulations.libreV2.com.cumulations.libreV2.BLE.BLEServiceToApplicationInterface;
import com.cumulations.libreV2.com.cumulations.libreV2.BLE.BleCommunication;
import com.cumulations.libreV2.com.cumulations.libreV2.BLE.ConfigurationParameters;
import com.cumulations.libreV2.model.ScanResultItem;
import com.cumulations.libreV2.model.WifiConnection;
import com.google.android.material.textfield.TextInputLayout;
import com.libreAlexa.LibreApplication;
import com.libreAlexa.R;
import com.libreAlexa.constants.AppConstants;
import com.libreAlexa.constants.Constants;
import com.libreAlexa.luci.LSSDPNodes;
import com.libreAlexa.netty.LibreDeviceInteractionListner;
import com.libreAlexa.netty.NettyData;
import com.libreAlexa.util.LibreLogger;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CTBluetoothPassCredientials extends CTDeviceDiscoveryActivity implements BLEServiceToApplicationInterface, View.OnClickListener, LibreDeviceInteractionListner {

    EditText et_mDeviceName;
    EditText et_wifi_password;
    TextView tv_selected_wifi;
    TextView tv_security;
    Button btn_next;
    Button btn_cancel;
    String passphrase;
    ImageView iv_right_arrow;
    ImageView iv_back;
    TextInputLayout textInput_password_wifi;
    boolean mIntentExtraScanResults ;
    String mDeviceName;
    private BluetoothLeService mBluetoothLeService;
    ConfigurationParameters configurationParameters = ConfigurationParameters.getInstance();
    private static final String TAG="==CTBluetoothPass";
    CheckBox rememCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ct_activity_connect_to_wifi);
        Log.d(TAG, "onCreate: CTBluetoothPassCredientials");
        initViews();
        getIntentExtra();
        initBluetoothAdapterAndListener();

    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    public void initBluetoothAdapterAndListener(){
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onPause() {
       // unbindService(mServiceConnection);
        super.onPause();
    }
    BluetoothAdapter mBluetoothAdapter = null;
    String mDeviceAddress ;

    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {

            Log.d(TAG, "Service connected");
            isItDying  = false;
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize( mBluetoothAdapter ,CTBluetoothPassCredientials.this)) {
                Log.d(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mBluetoothLeService.connect(mDeviceAddress);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }

        @Override
        public void onBindingDied(ComponentName name) {
            isItDying = true;
        }
    };
    private boolean isItDying = false;
    public void getIntentExtra(){
        mIntentExtraScanResults = getIntent().getBooleanExtra(Constants.CONFIG_THRO_BLE, true);
        mDeviceName = getIntent().getStringExtra(AppConstants.DEVICE_NAME);
        Log.d(TAG," Device Name "+mDeviceName);
        //Added by Shaik Have to Confirm with suma
       // mDeviceName="EA-300-LYNK_0a07";
        et_mDeviceName.setText(mDeviceName);
        mDeviceAddress = getIntent().getStringExtra(AppConstants.DEVICE_BLE_ADDRESS);
    }

    @Override
    public void onBackPressed() {
        mBluetoothLeService.close();
        mBluetoothLeService.disconnect();
        callBluetoothDeviceListActivity();
        super.onBackPressed();
    }

    public void initViews(){
        et_mDeviceName = findViewById(R.id.et_device_name);
        et_mDeviceName.setEnabled(true);
        et_wifi_password = findViewById(R.id.et_wifi_password);
        tv_selected_wifi = findViewById(R.id.tv_selected_wifi);
        textInput_password_wifi=findViewById(R.id.password_wifi);
        rememCheckBox = findViewById(R.id.rememCheckBox);

        tv_security = findViewById(R.id.tv_security);
        btn_next = findViewById(R.id.btn_next);
        btn_next.setOnClickListener(this);
        btn_cancel = findViewById(R.id.btn_cancel);
        btn_cancel.setOnClickListener(this);
        btn_cancel.setEnabled(true);
        iv_right_arrow = findViewById(R.id.iv_right_arrow);
        iv_right_arrow.setOnClickListener(this);
        tv_selected_wifi.setOnClickListener(this);
        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);

    }
    final Handler handler  = new Handler();
    final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            dismissDialog();
        }
    };
    @Override
    public void onConnectionSuccess(final BluetoothGattCharacteristic value) {
         runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showProgressDialog(getString(R.string.get_scan_results));
                int timeout = 500;
                if(mDeviceName.length() == 0 ) {
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            byte[] data = new byte[0];
                            BLEPacket mBlePacketScanWIFI = new BLEPacket(data, (byte) BLE_SAC_APP2DEV_FRIENDLYNAME, true);
                            BleCommunication.writeDataToBLEDevice(value, mBlePacketScanWIFI);
                            //  getFriendlyNameThroBLE();
                        }
                    }, timeout);
                } else {
                    timeout = 0;
                }
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        byte[] data = new byte[0];
                        BLEPacket mBlePacketScanWIFI = new BLEPacket(data, (byte) BLE_SAC_APP2DEV_SECURITY_CHECK,true);
                        BleCommunication.writeDataToBLEDevice(value, mBlePacketScanWIFI);
                        //  getFriendlyNameThroBLE();
                    }
                }, timeout + 1000);

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        byte[] data = new byte[0];
                        BLEPacket mBlePacketScanWIFI = new BLEPacket(data, (byte) BLE_SAC_APP2DEV_SCAN_WIFI,true);
                        BleCommunication.writeDataToBLEDevice(value, mBlePacketScanWIFI);
                        //  getFriendlyNameThroBLE();
                    }
                }, timeout + 1500);

                handler.postDelayed(runnable, 12000);
            }
        });
    }
    /**
     *  public static final int BLE_SAC_DEV2APP_CRED_RECEIVED = 20;
     *     public static final int BLE_SAC_DEV2APP_CRED_SUCCESS = 21;
     *     public static final int BLE_SAC_DEV2APP_CRED_FAILURE = 22;
     *     public static final int BLE_SAC_DEV2APP_WIFI_CONNECTING = 23;
     *     public static final int BLE_SAC_DEV2APP_WIFI_CONNECTED = 24;
     *     public static final int BLE_SAC_DEV2APP_WIFI_CONNECTING_FAILED = 25;
     *
     *     public static final int BLE_SAC_DEV2APP_WIFI_STATUS = 26;
     *     public static final int BLE_SAC_DEV2APP_WIFI_AP_NOT_FOUND = 27;
     *     public static final int BLE_SAC_DEV2APP_WIFI_DISCONNECTED = 28;
     *     */
    @Override
    public void receivedBLEDataPacket(BLEPacket.BLEDataPacket packet) {
        Log.d(TAG, "BLE: packet.getCommand() " +packet.getCommand()) ;
        switch(packet.getCommand()) {
            case BLE_SAC_APP2DEV_FRIENDLYNAME:
                if(packet.getcompleteMessage().length > 0) {
                    byte[] mDeviceNameArray = new byte[packet.getDataLength()];
                    for(int i =0 ;i<packet.getDataLength();i++) {
                        mDeviceNameArray[i] = packet.getMessage()[i];
                    }

                    Log.d(TAG, "receivedBLEDataPacket from Array " + new String(packet.getMessage())) ;
                    mDeviceName = new String(mDeviceNameArray);
                    Log.d(TAG, "SettingDeviceName " + mDeviceName) ;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            et_mDeviceName.setText(mDeviceName);
                        }
                    });
                    Log.d(TAG, "receivedBLEDataPacket " + mDeviceName) ;
                }
                break;
            case  BLE_SAC_DEV2APP_CRED_RECEIVED:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setMessageProgressDialog(getString(R.string.cred_received));
                    }
                });

                break;
            case BLE_SAC_DEV2APP_CRED_SUCCESS:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showAlertMessageRegardingSAC(" " ,getString(R.string.cred_success));
                    }
                });

               /* byte data[] = new byte[0];
                BLEPacket mBlePacketScanWIFI = new BLEPacket(data, (byte) BLE_SAC_APP2DEV_STOP);
                BleCommunication.writeDataToBLEDevice(mBlePacketScanWIFI);*/

                break;
            case BLE_SAC_DEV2APP_CRED_FAILURE:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showAlertMessageRegardingSAC(" " ,getString(R.string.credientials_invalid));
                    }
                });

                break;
            case BLE_SAC_DEV2APP_WIFI_CONNECTING:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setMessageProgressDialog(getString(R.string.start_connecting));
                    }
                });

                break;
            case BLE_SAC_DEV2APP_WIFI_CONNECTED:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setMessageProgressDialog(getString(R.string.speaker_connected));
                    }
                });
                byte[] data1 = new byte[0];
                BLEPacket mBleStop = new BLEPacket(data1, (byte) BLE_SAC_APP2DEV_STOP_M);
                BleCommunication.writeDataToBLEDevice(mBleStop);

                goToConnectToMainNetwork();
                break;
            case BLE_SAC_DEV2APP_WIFI_CONNECTING_FAILED:

                byte[] mMessageInt = packet.getcompleteMessage();
                Log.d(TAG , "Bluetooth Received Message length  " + mMessageInt.length);
                int message = mMessageInt[3];
                Log.d(TAG , "Bluetooth Received Message " + message);
                if(message == 26) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showAlertMessageRegardingSAC(getString(R.string.configuration_failed_hd) ,getString(R.string.configuration_failed_msg));
                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showAlertMessageRegardingSAC(getString(R.string.configuration_failed_hd) ,getString(R.string.configuration_timeout_msg));
                        }
                    });
                }
                break;
            case BLE_SAC_DEV2APP_WIFI_AP_NOT_FOUND:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setMessageProgressDialog(getString(R.string.ap_notfound));
                    }
                });

                break;
            case BLE_SAC_DEV2APP_WIFI_DISCONNECTED:
                break;
            case BLE_SAC_DEV2APP_STARTED:
                break;
            case BLE_SAC_DEV2APP_SCAN_LIST_START:
                constructJSonString = new StringBuilder();
                break;
            case BLE_SAC_DEV2APP_SCAN_LIST_DATA:
               // Log.d(TAG, new String (packet.getMessage()));
                constructJSonString.append(new String(packet.getMessage()));
                break;
            case BLE_SAC_DEV2APP_SCAN_LIST_END:
                populateScanlistMap(constructJSonString.toString());
                dismissDialog();
                break;
            /*case BLE_SAC_DEV2APP_WIFI_STATUS :
                //byte[] mData = new byte[0];
               // BLEPacket mBleWifiStatus = new BLEPacket(mData, (byte) BLE_SAC_APP2DEV_SCAN_WIFI);
                //BleCommunication.writeDataToBLEDevice(mBleWifiStatus);
                break;*/
            case BLE_SAC_APP2DEV_SECURITY_CHECK:
                Log.d(TAG, "KARUNAKARAN  " + packet.getDataLength());
                int security = 0;
                if(packet.getDataLength() > 0) {
                    byte[] mMessageInt1 = packet.getcompleteMessage();
                    security = (int) mMessageInt1[4]; //Integer.parseInt(mMessageInt1[4])
                    Log.d(TAG, "KARUNAKARAN  security" + security);// ;
                }
                mSecurityCheckEnabled = security != 0;
                break;

        }
    }

    boolean mSecurityCheckEnabled = false;

    @SuppressWarnings("deprecation")
    public static Spanned fromHtml(String html){
        if(html == null){
            // return an empty spannable if the html is null
            return new SpannableString("");
        }else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // FROM_HTML_MODE_LEGACY is the behaviour that was used for versions below android N
            // we are using this flag to give a consistent behaviour
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        } else {
            return Html.fromHtml(html);
        }
    }
    Map<String,String> scanListMap = new TreeMap<>();
    public void populateScanlistMap(final String scanList){
        scanListMap.clear();
        try {
            JSONObject mainObj = new JSONObject(scanList);
            JSONArray scanListArray = mainObj.getJSONArray("Items");
            for (int i =0;i< scanListArray.length();i++){
                JSONObject obj = (JSONObject) scanListArray.get(i);
                if (obj.getString("SSID")==null
                        || (obj.getString("SSID").isEmpty())){
                    continue;
                }

                scanListMap.put(fromHtml(obj.getString("SSID")).toString() ,fromHtml(obj.getString("Security")).toString());
                Log.d(TAG,"BLE" + scanListMap.get(obj.getString("SSID"))+" ssid: "+ obj.getString("SSID"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        for (String str : scanListMap.keySet()) {
            System.out.println(str);
           // Log.d(TAG,"suma in wifi scan list"+str);
            WifiConnection.getInstance().putWifiScanResultSecurity(str, scanListMap.get(str));
        }

    }


    StringBuilder constructJSonString = new StringBuilder();
    public void showAlertMessageRegardingSAC(String title, final String message) {
        dismissDialog();
        if(!isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            //Uncomment the below code to Set the message and title from the strings.xml file
            builder.setMessage(message) .setTitle(title)
                    .setCancelable(false)
                    .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            if(message.equalsIgnoreCase(getString(R.string.credientials_invalid))) {
                               // byte[] mData = new byte[0];
                                // BLEPacket mBleWifiStatus = new BLEPacket(mData, (byte) BLE_SAC_APP2DEV_TRIGGER_SAC);
                               // BleCommunication.writeDataToBLEDevice(mBleWifiStatus);
                            }
                            dialog.dismiss();
                        }
                    });
            //Creating dialog box
            AlertDialog alert = builder.create();
            alert.show();
        }
    }
    @Override
    public void writeSucess(int status) {

    }

    @Override
    public void onDisconnectionSuccess(int status) {

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.et_device_name) {
        } else if (id == R.id.btn_next) {
            try {
                btnNextClicked();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (id == R.id.btn_cancel) {
            btnCancelClicked();
        } else if (id == R.id.ll_select_wifi || id == R.id.iv_right_arrow
            || id == R.id.tv_selected_wifi) {
            ivRightArrowClicked();
        } else if (id == R.id.iv_back) {//mBluetoothLeService.disconnect();
            //mBluetoothLeService.close();
            //mBluetoothLeService.removelistener(this);
            callBluetoothDeviceListActivity();
        }
    }

    /**
     * -> BLE_SAC_APP2DEV_CONNECT_WIFI
     * 		: |0xAB|0x01|Len| Data|0xCB|
     * 			Data Format: |SSID_LEN|SSID|PASSPHRASE_LEN|PASSPHRASE
     *                              SSID_LEN               : 1Byte                 -> Length of the AP SSID ( Max: 32)
     * 							 SSID                   : <=32 bytes            -> Name of the AP
     * 							 PASSPHRASE_LEN         : 1Byte 	 			-> Length of the Password ( 8 to 63 Bytes)
     * 							 PASSPHRASE         	: >=8 && <=63           -> Password
     **/
    public void btnNextClicked() throws Exception{
        Log.d(TAG, "btnNextClicked: ");
        String mSelectedSSID = new String (WifiConnection.getInstance().getMainSSID().getBytes() , StandardCharsets.UTF_8);
        String mSelectedPass = new String(et_wifi_password.getText().toString().getBytes(), StandardCharsets.UTF_8);
        String mSelectedSecurity = new String (WifiConnection.getInstance().getMainSSIDSec().getBytes(), StandardCharsets.UTF_8);
        String mSelectedCountryCode = new String( configurationParameters.getDeviceCountryCode(CTBluetoothPassCredientials.this).getBytes(), StandardCharsets.UTF_8).toUpperCase();
        mDeviceName = new String(et_mDeviceName.getText().toString().getBytes(), StandardCharsets.UTF_8);
        Log.d(TAG, "btnNextClicked: mDeviceName: "+mDeviceName);
        WifiConnection.getInstance().setMainSSIDPwd(mSelectedPass);
        Log.d(TAG , " Security check is enabled or Not 0(Disabled)/1(Enabled) " + mSecurityCheckEnabled  + " Countrycode " + mSelectedCountryCode );
        if(!mSecurityCheckEnabled) {
            Log.d(TAG, "btnNextClicked: mSecurityCheckEnabled");
            byte[] data = new byte[mSelectedPass.length() + mSelectedSSID.length() + 5 + mSelectedSecurity.length() + et_mDeviceName.getText().length() + mSelectedCountryCode.length()];
            int i = 0;
            data[i++] = (byte) mSelectedSSID.length();
            for(byte b : mSelectedSSID.getBytes()) {
                data[i++] = b;
            }

            data[i++] = (byte)mSelectedPass.length();
            for(byte b : mSelectedPass.getBytes()){
                data[i++] = b;
            }

            data[i++] = (byte)mSelectedSecurity.length();
            for(byte b : mSelectedSecurity.getBytes()) {
                data[i++] = b;
            }

            data[i++] = (byte)et_mDeviceName.getText().length();
            for(byte b :et_mDeviceName.getText().toString().getBytes()) {
                data[i++] = b;
            }

            data[i++] = (byte) mSelectedCountryCode.length();
            for(byte b : mSelectedCountryCode.getBytes()) {
                data[i++] = b;
            }
            BLEPacket mBlePacketScanWIFI = new BLEPacket(data, (byte) BLE_SAC_APP2DEV_CONNECT_WIFI,true);
            BleCommunication.writeDataToBLEDevice(mBlePacketScanWIFI);
        } else {
            Log.d(TAG, "btnNextClicked: mSecurityCheckEnabled ELSE ");
/*Code we are sending ssid password*/

            ConfigurationParameters.ConfigPacket mConfigPacket = ConfigurationParameters.getInstance().getEncryptedDataAndKey(mSelectedSSID, mSelectedPass, mSelectedSecurity, mDeviceName, mSelectedCountryCode);
            //ConfigurationParameters.getInstance().createSacPackets(false, mConfigPacket.getEncodedData(),mConfigPacket.getIv());
        /*byte[] ThreeTimesOfEncodedData = new byte[mConfigPacket.getEncodedData().length * 3];
        int i =0;
        for(byte b : mConfigPacket.getEncodedData()) {
            ThreeTimesOfEncodedData[i++] =  b;
        }
        for(byte b : mConfigPacket.getEncodedData()) {
            ThreeTimesOfEncodedData[i++] =  b;
        }
        for(byte b : mConfigPacket.getEncodedData()) {
            ThreeTimesOfEncodedData[i++] =  b;
        }*/
            byte[] encodedData = mConfigPacket.getEncodedData();//ThreeTimesOfEncodedData ;//mConfigPacket.getEncodedData();
            byte[] ivData = mConfigPacket.getIv();
            int NumberOfPacketsToSplitted = encodedData.length / 150; // MTCU_SIZE - header just to make it as whole number
            if ((encodedData.length % 150) != 0) {
                NumberOfPacketsToSplitted += 1;
            }
            int offset = 0;
            int lengthTocopy = 150;
            if (encodedData.length < 150) {
                lengthTocopy = encodedData.length;
            }

            while (NumberOfPacketsToSplitted > 0) {
                Log.d(TAG, " KARUNAKARAN " + " NumberofPacketstoBeSplitted " + NumberOfPacketsToSplitted +
                        " Offset " + offset +
                        " LengthToCopy " + lengthTocopy +
                        " EncodedData Length " + encodedData.length);
                NumberOfPacketsToSplitted--;
                byte[] offsetEncodedData = configurationParameters.getByteArrayFromOffset(offset, lengthTocopy, encodedData);
                byte[] dataToSendToDevice = configurationParameters.createSacPackets(NumberOfPacketsToSplitted, offsetEncodedData, ivData);
                BleCommunication.writeDataToBLEDevice(dataToSendToDevice);
                offset += 150;
                if (NumberOfPacketsToSplitted == 1) {
                    lengthTocopy = encodedData.length - offset;
                }
            }
        }
        Log.d(TAG, "btnNextClicked: Before Posting credentials "+et_mDeviceName.getText().toString());
        mDeviceName = et_mDeviceName.getText().toString();
        setMessageProgressDialog("Posting credentials ....");

        if (rememCheckBox.isChecked()) {
            Log.d(TAG,"suma in get the stored CredValue isChecked\n");
            AppUtils.INSTANCE.storeSSIDInfoToSharedPreferences(CTBluetoothPassCredientials.this,WifiConnection.getInstance().getMainSSID(), WifiConnection.getInstance().getMainSSIDPwd())  ;

        }
    }

    public void btnCancelClicked(){
        //mBluetoothLeService.disconnect();
        //mBluetoothLeService.close();
        mBluetoothLeService.removelistener(this);
       // unbindService(mServiceConnection);
        callBluetoothDeviceListActivity();
      //  finish();
    }

    public void ivRightArrowClicked() {
        if(WifiConnection.getInstance().getSavedScanResults().isEmpty()) {
            showAlertMessageRegardingSAC("Alert Message !! ", " Scan List is Empty");
            return;
        }
        Intent mIntent = new Intent(this, CTWifiListActivity.class);
        mIntent.putExtra(Constants.CONFIG_THRO_BLE,mIntentExtraScanResults);
        Log.d(TAG, "ivRightArrowClicked: startActivityForResult started");
        //startActivityForResult(mIntent, AppConstants.GET_SELECTED_SSID_REQUEST_CODE);
        customStartActivityForResult(AppConstants.GET_SELECTED_SSID_REQUEST_CODE,mIntent);
    }
    @Override
    protected void customOnActivityResult(@Nullable Intent data, int requestCode, int resultCode) {
        super.customOnActivityResult(data, requestCode, resultCode);
        if (requestCode == AppConstants.GET_SELECTED_SSID_REQUEST_CODE) {
            if (resultCode == AppCompatActivity.RESULT_OK) {
                ScanResultItem mScanResultItem = (ScanResultItem) data.getSerializableExtra(AppConstants.SELECTED_SSID);

                tv_selected_wifi.setVisibility(View.VISIBLE);
                tv_selected_wifi.setText(mScanResultItem.getSsid());
                LibreLogger.d(this, "suma  in get the stored CredValue getSSID\n");

                iv_right_arrow.setVisibility(View.GONE);
                tv_security.setText("Security Type : " + mScanResultItem.getSecurity());
                WifiConnection wifiConnect = WifiConnection.getInstance();
                wifiConnect.setMainSSID(mScanResultItem.getSsid());
                wifiConnect.setMainSSIDSec(mScanResultItem.getSecurity());
                if (mScanResultItem.getSecurity().equals("NONE")) {
                    textInput_password_wifi.setVisibility(View.GONE);
                } else {
                    textInput_password_wifi.setVisibility(View.VISIBLE);
                }

                passphrase = getSSIDPasswordFromSharedPreference(mScanResultItem.getSsid());
                if(passphrase!=null) {
                    LibreLogger.d(this, "suma  in get the stored CredValue getPWD\n" + passphrase);
                    et_wifi_password.setText(passphrase);
                }
            }
        }

    }


    /*It will get password for corresponding ssid */
    private String getSSIDPasswordFromSharedPreference(String deviceSSID) {

        SharedPreferences pref = getApplicationContext()
            .getSharedPreferences("Your_Shared_Prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.commit();
        Log.d(TAG,"suma in get the stored CredValue saved password"+ pref.getString(deviceSSID, ""));

        et_wifi_password.setText(pref.getString(deviceSSID, ""));

        return pref.getString(deviceSSID, "");

    }
    private void callBluetoothDeviceListActivity() {
        Intent intent = new Intent(this, CTBluetoothDeviceListActivity.class);
        startActivity(intent);
        finish();
    }

    public void goToConnectToMainNetwork() {

        WifiConnection.getInstance().setmSACDevicePostDone(true);
        LibreApplication.sacDeviceNameSetFromTheApp = et_mDeviceName.getText().toString();
        startActivity(new Intent(this,CTConnectingToMainNetwork.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    public void goToConnectToMainNetwork(LSSDPNodes mNode) {
        WifiConnection.getInstance().setmSACDevicePostDone(true);
        LibreApplication.sacDeviceNameSetFromTheApp = et_mDeviceName.getText().toString();
        startActivity(new Intent(this,CTConnectingToMainNetwork.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(AppConstants.DEVICE_IP, mNode.getIP()));
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mBluetoothLeService != null) {
          //  mBluetoothLeService.disconnect();
           // mBluetoothLeService.close();
            mBluetoothLeService.removelistener(this);
        }
        dismissDialog();
        unbindService(mServiceConnection);
        mBluetoothLeService = null;

    }

    @Override
    public void deviceDiscoveryAfterClearingTheCacheStarted() {

    }

    @Override
    public void newDeviceFound(LSSDPNodes node) {
        Log.d(TAG, "newDeviceFound: sacName: "+LibreApplication.sacDeviceNameSetFromTheApp);
        Log.d(TAG, "newDeviceFound: FriendlyName "+node.getFriendlyname());
        if (LibreApplication.sacDeviceNameSetFromTheApp.equals(node.getFriendlyname())) {
            goToConnectToMainNetwork(node);
        }else{
            Log.d(TAG, "newDeviceFound: coming to else");
        }
    }

    @Override
    public void deviceGotRemoved(String ipaddress) {

    }

    @Override
    public void messageRecieved(NettyData packet) {

    }
}
