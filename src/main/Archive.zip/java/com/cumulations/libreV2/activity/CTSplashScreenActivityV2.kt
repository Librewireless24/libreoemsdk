package com.cumulations.libreV2.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.cumulations.libreV2.appInForeground
import com.google.android.gms.common.internal.GmsLogger
import com.libreAlexa.LibreApplication
import com.libreAlexa.LibreApplication.GLOBAL_TAG
import com.libreAlexa.R
import com.libreAlexa.app.dlna.dmc.processor.upnp.LoadLocalContentService

class CTSplashScreenActivityV2 : CTDeviceDiscoveryActivity() {
    companion object{
        val TAG:String=CTSplashScreenActivityV2::class.java.simpleName
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ct_activity_splash)

    }
    override fun proceedToHome() {
        openNextScreen()
    }

    private fun openNextScreen() {
        Log.d(GLOBAL_TAG, "openNextScreen: "+LibreApplication.LOCAL_IP)
        Handler(Looper.getMainLooper()).post {
            if (!LibreApplication.LOCAL_IP.isNullOrEmpty() && appInForeground(this)) {
                startService(Intent(this@CTSplashScreenActivityV2, LoadLocalContentService::class.java))
            }
        }
          intentToHome(this)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        killApp()
    }
}