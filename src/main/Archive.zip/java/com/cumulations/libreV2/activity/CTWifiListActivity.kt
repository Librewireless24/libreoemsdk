package com.cumulations.libreV2.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.cumulations.libreV2.AppUtils
import com.cumulations.libreV2.adapter.CTWifiListAdapter
import com.cumulations.libreV2.model.ScanResultItem
import com.cumulations.libreV2.model.ScanResultResponse
import com.cumulations.libreV2.model.WifiConnection
import com.cumulations.libreV2.toHtmlSpanned
import com.google.gson.Gson
import com.libreAlexa.LErrorHandeling.LibreError
import com.libreAlexa.R
import com.libreAlexa.constants.AppConstants
import com.libreAlexa.constants.Constants
import com.libreAlexa.databinding.CtActivityWifiListBinding
import com.libreAlexa.serviceinterface.LSDeviceClient
import com.libreAlexa.util.LibreLogger
import retrofit.Callback
import retrofit.RetrofitError
import retrofit.client.Response


class CTWifiListActivity: CTDeviceDiscoveryActivity() {
    private var wifiListAdapter: CTWifiListAdapter? = null
    private var filteredScanResults: ArrayList<ScanResultItem>? = ArrayList()
    private var mConfiguringThroughBLE = false
    private lateinit var binding: CtActivityWifiListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = CtActivityWifiListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //Commented by SHAIK discussed with SUMA
        //disableNetworkChangeCallBack()
        initViews()
        setListeners()
    }

    private fun setListeners() {
        binding.ivBack.setOnClickListener{ onBackPressed() }

        binding.swipeRefresh.setOnRefreshListener {
            WifiConnection.getInstance().clearWifiScanResult()
            filteredScanResults?.clear()
            wifiListAdapter?.scanResultList?.clear()
            wifiListAdapter?.notifyDataSetChanged()
            getScanResultsFromDevice()
        }
    }

    private fun initViews() {
        binding.toolbar.title = ""
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        wifiListAdapter = CTWifiListAdapter(this, ArrayList())
        binding.rvWifiList.layoutManager = LinearLayoutManager(this)
        binding.rvWifiList.adapter = wifiListAdapter

        mConfiguringThroughBLE = intent.getBooleanExtra(Constants.CONFIG_THRO_BLE,false)
        if(mConfiguringThroughBLE) {
            binding.swipeRefresh.isEnabled = false
        }
    }

    override fun onStart() {
        super.onStart()
        getScanResultsFromDevice()
    }

    private fun getScanResultsFromDevice(){
        val ssid = getConnectedSSIDName(this)
        if(!mConfiguringThroughBLE) {
            if (!(ssid.contains(Constants.SA_SSID_RIVAA_CONCERT) || ssid.contains(Constants.SA_SSID_RIVAA_STADIUM) || ssid.contains(".d"))) {
                    AppUtils.showAlertForNotConnectedToSAC(this)
                    return
                }
        }

        if (WifiConnection.getInstance().savedScanResults.isEmpty()){
            getScanResultsForIp(intent?.getStringExtra(AppConstants.DEVICE_IP)!!)
        } else {
            binding.rvWifiList.visibility = View.VISIBLE
            binding.tvNoData.visibility = View.GONE

            filteredScanResults = WifiConnection.getInstance().savedScanResults as ArrayList<ScanResultItem>?
            wifiListAdapter?.updateList(filteredScanResults)
        }
    }

    private fun getScanResultsForIp(deviceIp: String) {
        showProgressDialog(R.string.getting_scan_results)
        binding.swipeRefresh.isRefreshing = true
        Log.d("getScanResultsForIp","ip = $deviceIp")
        val BASE_URL = "http://$deviceIp:80"
        val lsDeviceClient = LSDeviceClient(BASE_URL)
        val deviceNameService = lsDeviceClient.deviceNameService

        deviceNameService.getScanResultV2(object : Callback<String>{
            override fun success(stringResponse: String?, response: Response?) {
                dismissDialog()
                binding.swipeRefresh.isRefreshing = false
                if (stringResponse == null)
                    return

                /*val listType = object : TypeToken<List<ScanResultItem>>() {}.type
                val scanResultItems:List<ScanResultItem> = Gson().fromJson(stringResponse, listType)*/

                val scanResultResponse = Gson().fromJson(stringResponse,ScanResultResponse::class.java)
                        ?: return

                if (scanResultResponse.items?.isEmpty()!!){
                    binding.tvNoData.visibility = View.VISIBLE
                    binding.rvWifiList.visibility = View.GONE
                } else {
                    binding.rvWifiList.visibility = View.VISIBLE
                    binding.tvNoData.visibility = View.GONE

                    sortAndSaveScanResults(scanResultResponse.items)
                    wifiListAdapter?.updateList(filteredScanResults)
                }
            }

            override fun failure(error: RetrofitError?) {
                dismissDialog()
                binding.swipeRefresh.isRefreshing = false
                Log.e("getScanResultsForIp", error?.message!!)
                showToast(error.message!!)
                if (error.message?.contains("failed to connect to")!!){
                    finish()
                } /*else getScanResultsForIp(deviceIp)*/
            }

        })
    }


    internal var handler: Handler? = object : Handler(Looper.getMainLooper()) {

        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            Log.d("handler","${msg.what} timeout")
            when(msg.what){
                Constants.GETTING_SCAN_RESULTS ->{
                    Log.d("handler","${msg.what} timeout")
                    dismissDialog()
                    /*showing error*/
                    val error = LibreError("", getString(R.string.requestTimeout))
                    showErrorMessage(error)
                }
            }
        }
    }

    private fun sortAndSaveScanResults(list: List<ScanResultItem>?) {
        /*Sorted in ascending order for keys*/

        val unSortedHashmap = HashMap<String,String>()
        for (item in list!!){
            item.ssid = item.ssid.toHtmlSpanned().toString()
            item.security = item.security.toHtmlSpanned().toString()
            LibreLogger.d(this,"suma in wifi scan list item security"+item.security+"alternate"+item.security.toHtmlSpanned().toString())
            unSortedHashmap[item.ssid] = item.security
            if (!item.ssid.contains(Constants.RIVAA_WAC_SSID)){
                filteredScanResults?.add(item)
            }
        }

        val sortedMap = unSortedHashmap.toSortedMap()
        sortedMap.forEach { (key, value) ->
            println("$key => $value")
            WifiConnection.getInstance().putWifiScanResultSecurity(key, value)
        }
    }

    fun goBackToConnectWifiScreen(scanResultItem: ScanResultItem){
        setResult(Activity.RESULT_OK, Intent().apply {
            putExtra(AppConstants.SELECTED_SSID,scanResultItem)
        })
        finish()
    }

    override fun onStop() {
        super.onStop()
        handler?.removeCallbacksAndMessages(null)
    }
}