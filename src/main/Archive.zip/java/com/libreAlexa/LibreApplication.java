package com.libreAlexa;
/*********************************************************************************************
 * Copyright (C) 2014 Libre Wireless Technology
 * <p/>
 * "Junk Yard Lab" Project
 * <p/>
 * Libre Sync Android App
 * Author: Subhajeet Roy
 ***********************************************************************************************/

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import androidx.multidex.BuildConfig;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;
import com.libreAlexa.Ls9Sac.FwUpgradeData;
import com.libreAlexa.Scanning.ScanThread;
import com.libreAlexa.alexa.MicExceptionListener;
import com.libreAlexa.alexa.MicTcpServer;
import com.libreAlexa.app.dlna.dmc.utility.PlaybackHelper;
import com.libreAlexa.util.GoogleTOSTimeZone;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;


public class LibreApplication extends MultiDexApplication implements
    MicTcpServer.MicTcpServerExceptionListener {

  public static boolean mCleanUpIsDoneButNotRestarted = false;
  public static boolean isWifiON = false;
  public static InputStream openRawandroidp12;
  public static String getMYPEMstring = "";
  public static Activity ContextActivity;
  public static int disconnectedCount = 0, betweenDisconnectedCount = 0;
  public static boolean noReconnectionRuleToApply = false;
  public static boolean GOOGLE_TOS_ACCEPTED = false;
  public static String thisSACDeviceNeeds226 = "";
  public static String sacDeviceNameSetFromTheApp = "";
  public static boolean mLuciThreadInitiated = false;
  public static boolean isPasswordEmpty = false;

  public static boolean isSacFlowStarted = false;

  public static boolean hideErrorMessage;
  //public static final String GLOBAL_TAG = LibreApplication.class.getSimpleName();
  public static final String GLOBAL_TAG = "GLOBAL_TAG";

  public static String activeSSID;
  public static String mActiveSSIDBeforeWifiOff;
  public static String currentTrackName = "-1";
  public static String currentArtistName = "-1";
  public static String currentAlbumnName = "-1";
  public static String currentAlbumArtView = "-1";

  /*this map is having all devices volume(64) based on IP address*/
  public static HashMap<String, Integer> INDIVIDUAL_VOLUME_MAP = new HashMap<>();

  public static HashMap<String, GoogleTOSTimeZone> GOOGLE_TIMEZONE_MAP = new HashMap<>();

  public static LinkedHashMap<String, FwUpgradeData> FW_UPDATE_AVAILABLE_LIST = new LinkedHashMap<>();

  /*this map is having zone volume(219) only for master to avoid flickering in active scene*/
  public static HashMap<String, Integer> ZONE_VOLUME_MAP = new HashMap<>();
  public static int mTcpPortInUse = -1;
  private MicTcpServer micTcpServer;

  /**
   * This hashmap stores the DMRplayback helper for a udn
   */
  public static HashMap<String, PlaybackHelper> PLAYBACK_HELPER_MAP = new HashMap<String, PlaybackHelper>();
  public static String LOCAL_UDN = "";
  public static String LOCAL_IP = "";
  ScanThread wt = null;
  Thread scanThread = null;
  private MicExceptionListener micExceptionActivityListener;

  /*Vodafone Code*/
  public static int activityOnUiIndex = 0;
  public static int writingappkilled = -1;

  //Have to see where it is using
  @Override
  public void onTerminate() {
    super.onTerminate();
  }

  @Override
  public void onCreate() {
    super.onCreate();
    Log.d(GLOBAL_TAG, "LibreApplication onCreated");
    LibreApplication.openRawandroidp12 = getApplicationContext().getResources()
        .openRawResource(R.raw.android);

    if (BuildConfig.DEBUG) {
      Log.d(GLOBAL_TAG, "LibreApplication BuildConfig.DEBUG");
      StrictMode.setThreadPolicy(
          new StrictMode.ThreadPolicy.Builder()
              .detectDiskReads()
              .detectDiskWrites()
              .detectNetwork()   // or .detectAll() for all detectable problems
              .penaltyLog().build());
    }
    registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
      @Override
      public void onActivityCreated(Activity activity, Bundle bundle) {
      }

      @Override
      public void onActivityStarted(Activity activity) {
        activityOnUiIndex++;
      }

      @Override
      public void onActivityResumed(Activity activity) {
        LibreApplication.openRawandroidp12 = getApplicationContext().getResources()
            .openRawResource(R.raw.android);

      }

      @Override
      public void onActivityPaused(Activity activity) {

      }


      @Override
      public void onActivityStopped(Activity activity) {
        /*Vodafone Code*/
        activityOnUiIndex--;
      }

      @Override
      public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {

      }

      @Override
      public void onActivityDestroyed(Activity activity) {
        /*Vodafone Code*/
        LibreApplication.writingappkilled = activityOnUiIndex--;
      }
    });

  }

  /*Vodafone Code*/
  @Override
  protected void attachBaseContext(Context base) {
    super.attachBaseContext(base);
    Log.d(GLOBAL_TAG, "LibreApplication attachBaseContext");
    MultiDex.install(this);
  }

  public ScanThread getScanThread() {
    Log.d(GLOBAL_TAG, "LibreApplication Suma in check of getInstance6" + this.getClass().getName());
    return LibreEntryPoint.Companion.getInstance().getScanThread();
  }

  /**
   * clearing all collections related to application
   */
  public void clearApplicationCollections() {
    LibreEntryPoint.Companion.getInstance().clearApplicationCollections();
    Log.d(GLOBAL_TAG, "LibreApplication Suma in check of getInstance9" + this.getClass().getName());
  }

  public static boolean isApplicationActiveOnUI() {
    //Needed
    if (activityOnUiIndex > 0) {
      return true;
    } else {
    }
    return false;
  }

  //Move to LibreEntryPoint  class
  public synchronized void restart() {

    if (wt != null) {
      wt.close();
    }
    if (micTcpServer != null) {
      micTcpServer.close();
    }
    try {
      scanThread = new Thread(wt);
      scanThread.start();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public synchronized void micTcpStart() {
    try {
      Log.d(GLOBAL_TAG, "LibreApplication micTcpStart  called");
      ConnectivityManager connManager = (ConnectivityManager) getSystemService(
          Context.CONNECTIVITY_SERVICE);
      NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

      /*Can't get connectedSSID if location is off*/
            /*String connectedSSID = AppUtils.INSTANCE.getConnectedSSID(this);
            if (connectedSSID == null || connectedSSID.toLowerCase().contains(Constants.RIVAA_WAC_SSID.toLowerCase())) {
                return;
            }*/

      if (mWifi == null || !mWifi.isConnected()) {
        return;
      }

      micTcpServer = MicTcpServer.getMicTcpServer();
      micTcpServer.startTcpServer(this);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public synchronized void micTcpClose() {
    try {
      Log.d(GLOBAL_TAG, "LibreApplication micTcpClose  called");
      if (micTcpServer != null) {
        micTcpServer.close();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public void micTcpServerException(Exception e) {
    Log.d(GLOBAL_TAG, "LibreApplication micTcpServerException called = " + e.getMessage());
    if (micExceptionActivityListener != null) {
      Log.d(GLOBAL_TAG,"LibreApplication micTcpServerEx listener " + micExceptionActivityListener.getClass().getSimpleName());
      micExceptionActivityListener.micExceptionCaught(e);
    }
  }

  public void registerForMicException(MicExceptionListener listener) {
    Log.d(GLOBAL_TAG,"LibreApplication registerForMicException called");
    micExceptionActivityListener = listener;
  }

  public void unregisterMicException() {
    Log.d(GLOBAL_TAG,"LibreApplication unregisterMicException called");
    micExceptionActivityListener = null;
  }

  /*Future use*/
  /*private boolean isMobileDataEnabled() {
      boolean mobileDataEnabled = false;
      Log.d(GLOBAL_TAG,"suma check if mobile data is enabled or not");
      ConnectivityManager cm1 = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
      NetworkInfo info1 = null;
      if (cm1 != null) {
          info1 = cm1.getActiveNetworkInfo();
      }
      if (info1 != null) {
          if (info1.getType() == ConnectivityManager.TYPE_MOBILE) {
              try {
                  Class cmClass = Class.forName(cm1.getClass().getName());
                  Method method = cmClass.getDeclaredMethod("getMobileDataEnabled");
                  method.setAccessible(true);
                  mobileDataEnabled = (Boolean) method.invoke(cm1);
              } catch (Exception e) {
                  e.printStackTrace();
              }
          }

      }
      return mobileDataEnabled;
  }*/
  /*Future use*/
  private void myHandlingWhenAppForceStopped(Thread paramThread, Throwable paramThrowable) {
    Log.d("Alert", "Lets See if it Works !!!" + "paramThread:::" + paramThread + "paramThrowable:::"
        + paramThrowable);
    /* Killing our Android App with The PID For the Safe Case */
    int pid = android.os.Process.myPid();
    android.os.Process.killProcess(pid);
    System.exit(0);

  }
}
