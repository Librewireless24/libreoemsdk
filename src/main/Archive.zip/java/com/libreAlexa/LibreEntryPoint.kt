package com.libreAlexa

import android.content.Context
import android.net.ConnectivityManager
import android.net.ConnectivityManager.NetworkCallback
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.StrictMode
import android.os.StrictMode.ThreadPolicy
import android.util.Log
import com.cumulations.libreV2.tcp_tunneling.TunnelingControl
import com.libreAlexa.LibreApplication.*
import com.libreAlexa.Scanning.ScanThread
import com.libreAlexa.Scanning.ScanningHandler
import com.libreAlexa.alexa.MicExceptionListener
import com.libreAlexa.luci.LSSDPNodeDB
import com.libreAlexa.luci.LUCIControl
import java.io.IOException
import java.io.InputStream
import java.net.SocketException

class LibreEntryPoint() {
    private var appContext: Context? = null
    var scanthread: Thread? = null
    var mExecuted = false
    private var micExceptionActivityListener: MicExceptionListener? = null
    companion object {
        var wt: ScanThread? = null

        @Volatile
        private lateinit var instance: LibreEntryPoint
        fun getInstance(): LibreEntryPoint {
            Log.d(GLOBAL_TAG, "LibreEntryPoint  called")
            synchronized(this) {
                if (!Companion::instance.isInitialized) {
                    instance = LibreEntryPoint()
                }
                return instance
            }
        }
    }

    fun init(context: Context) {
        appContext = context
        Log.d(GLOBAL_TAG, "LibreEntryPoint Init on App Create Method Called")
        val connection_manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var input: InputStream? = null
        try {
            input = context.assets.open("server.pem")
        } catch (e: IOException) {
            e.printStackTrace()
        }
        //symmentrickey_of_productid.txt can't be more than 2 gigs.
        var size = 0
        try {
            if (input != null) {
                size = input.available()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        val buffer = ByteArray(size)
        try {
            input?.read(buffer)
        } catch (e: IOException) {
            e.printStackTrace()
        }
        try {
            input!!.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        // byte buffer into a string
        var text = String(buffer)
        text = text.replace("\n".toRegex(), "")
        //Log.d(GLOBAL_TAG, "msg digest symmentric  standard product ID mavidapplication$text")
        text = text.replace("-----BEGIN CERTIFICATE-----", "")
        text = text.replace("-----END CERTIFICATE-----", "")
        Log.d(GLOBAL_TAG, "msg digest symmentric  standard product ID mavidapplication2$text")
        getMYPEMstring = text
            //Libre Code
        val request: NetworkRequest.Builder?
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && !mExecuted) {
            request = NetworkRequest.Builder()
            request.addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            connection_manager.registerNetworkCallback(request.build(), object : NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        (context.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).bindProcessToNetwork(network)
                    } else {
                        ConnectivityManager.setProcessDefaultNetwork(network)
                    }
                    //Cross Checked in Moto 8.1 and OnePlus 12 with multiple networks working
                    // fine Suma has to confirm
                    val ip: String? = getIpAddress(context)
                    LOCAL_IP = if (ip != null && ip.trim().isNotEmpty()) {
                        ip
                    } else {
                        //IF the above New API code failed for safer side
                        getIpAddressOldAPI(context)
                    }
                }
            })
        } else {
            //Just for safer side below 5 versions
            LOCAL_IP = getIpAddressOldAPI(context)
        }
        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(ThreadPolicy.Builder().detectDiskReads().detectDiskWrites().detectNetwork() // or .detectAll() for all detectable problems
                .penaltyLog().build())
        }
    }

    fun initiateServices() {
        Log.d(GLOBAL_TAG, "LibreEntryPoint initiateServices started")
        initLUCIServices()
    }

    fun initLUCIServices() {
        //Log.d(GLOBAL_TAG, "initLUCIServices: LibreEntryPoint  $s")
        try {
            wt = ScanThread.getInstance()
            wt!!.setmContext(appContext)
            if (!mLuciThreadInitiated) {
                scanthread = Thread(wt)
                scanthread!!.start()
                mLuciThreadInitiated = true
            }
            Log.d(GLOBAL_TAG, "initLUCIServices LibreEntryPoint  mRunning $mLuciThreadInitiated")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /*    private fun isMobileDataEnabled(): Boolean {
    //Vodafone code
            Log.d(GLOBAL_TAG, "LibreEntryPoint Karuna mRunning AFTER  $mLuciThreadInitiated")
            var mobileDataEnabled = false
            val cm1 = appContext!!.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val info1: NetworkInfo? = cm1.activeNetworkInfo
            if (info1 != null) {
                if (info1.type == ConnectivityManager.TYPE_MOBILE) {
                    try {
                        val cmClass = Class.forName(cm1.javaClass.name)
                        val method = cmClass.getDeclaredMethod("getMobileDataEnabled")
                        method.isAccessible = true
                        mobileDataEnabled = method.invoke(cm1) as Boolean
                    } catch (e: java.lang.Exception) {
                        e.printStackTrace()
                    }
                }
            }
            return mobileDataEnabled
        }*/

    fun getScanThread(): ScanThread? {
        Log.d(GLOBAL_TAG, "LibreEntryPoint getScanThread called ")
        return wt
    }


    /**
     * clearing all collections related to application
     */
    fun clearApplicationCollections() {
        try {
            Log.d(GLOBAL_TAG, "LibreEntryPoint clearApplicationCollections() called with:")
            PLAYBACK_HELPER_MAP.clear()
            INDIVIDUAL_VOLUME_MAP.clear()
            ZONE_VOLUME_MAP.clear()
            TunnelingControl.clearTunnelingClients()
            LUCIControl.luciSocketMap.clear()
            LSSDPNodeDB.getInstance().clearDB()
            ScanningHandler.getInstance().clearSceneObjectsFromCentralRepo()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }


    @Synchronized
    @Throws(SocketException::class)
    fun restart() {
        if (wt != null) {
            wt!!.close()
        }/*if (micTcpServer != null) {
            micTcpServer.close();
        }*/
        try {
            scanthread = Thread(wt)
            scanthread!!.start()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    fun getIpAddress(context: Context): String? {
        var ipAddress: String? = null
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ipAddress = if (connectivityManager is ConnectivityManager) {
                connectivityManager.getLinkProperties(connectivityManager.activeNetwork)!!.linkAddresses[1].address.hostAddress!!
            } else {
                //Just for safer side
                getIpAddressOldAPI(appContext!!)
            }
        }
        return ipAddress
    }

    private fun getIpAddressOldAPI(context: Context): String {
        val ip: String?
        val wifiMan = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val wifiInf = wifiMan.connectionInfo
        val ipAddress = wifiInf.ipAddress
        ip = String.format("%d.%d.%d.%d", ipAddress and 0xff, ipAddress shr 8 and 0xff, ipAddress shr 16 and 0xff, ipAddress shr 24 and 0xff)
        return ip
    }
    //Change 4
    fun registerForMicException(listener: MicExceptionListener) {
        Log.d(GLOBAL_TAG, "LibreApplication registerForMicException called")
        micExceptionActivityListener = listener
    }
    fun unregisterMicException() {
        Log.d(GLOBAL_TAG, "LibreApplication unregisterMicException called")
        micExceptionActivityListener = null
    }
}