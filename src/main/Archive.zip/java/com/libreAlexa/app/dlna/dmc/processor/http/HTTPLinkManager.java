package com.libreAlexa.app.dlna.dmc.processor.http;

import java.util.HashMap;
import java.util.Map;

public class HTTPLinkManager {
	public static Map<String, String> LINK_MAP = new HashMap<String, String>();
}
